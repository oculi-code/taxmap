Im Ordner 1.2.0 finden Sie die Dateien gemäss Version 1.2.0 (genehmigt am 27.07.2023) des Standards eCH-0071 mit den Gemeinden ab dem 12.09.1848.
Die Version 1.1 wird nicht mehr aktualisiert.
Bei Fragen wenden Sie sich bitte an raumnomenklaturen@bfs.admin.ch

Dans le dossier 1.2.0 vous trouverez les fichiers selon la version 1.2.0 (approuvée le 27.07.2023) du standard eCH-0071 avec les communes à partir du 12.09.1848.
La version 1.1 ne sera plus actualisée.
En cas de questions, veuillez vous adresser à raumnomenklaturen@bfs.admin.ch

Nella cartella 1.2.0 troverete i file secondo la versione 1.2.0 (approvata il 27.07.2023) dello standard eCH-0071 con i Comuni a partire dal 12.09.1848.
La versione 1.1 non sarà più attualizzata.
In caso di domande vogliate rivolgervi a raumnomenklaturen@bfs.admin.ch
